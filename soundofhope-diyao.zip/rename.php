<?php
echo "前30集MP3更名为毫秒级的时间截<pre>\r\n";
$dir = './diyao/';
$files_list = scandir($dir);
foreach($files_list as $value){
    if(strpos($value, '.html') !== false){
        $fn = $dir . $value;
        $html_string = file_get_contents($fn);
        $regex = '/url?\=\/\/[^\",]+/i';
        preg_match_all($regex, $html_string, $matches);
        foreach($matches[0] as $link){
            if(strpos($link, '16K-mp3') !== false){
                $fn_16k_mp3 = trim(strrchr($link, '/'), '/');
                $path_16k_mp3 = '/caiji/c.php?' . str_replace($fn_16k_mp3, '', $link);
            }
            else{
                $fn_mp3 = trim(strrchr($link, '/'), '/');
                $path_mp3 = '/caiji/c.php?' . str_replace($fn_mp3, '', $link);
            }
        }
        $sec = rand(01, 60);
        $msec = rand(001, 999);
        $sec = str_pad($sec, 2, "0", STR_PAD_LEFT);
        $msec = str_pad($msec, 3, "0", STR_PAD_LEFT);
        $time_array = explode('|', $html_string);
        if(empty($time_array[1])) continue;
        $release_time = str_replace('.', '-', $time_array[1]);
        $release_time = trim($release_time) . ":$sec.$msec";
        $timestamps = get_data_format($release_time);
        # $fn, $fn_16k_mp3, $fn_mp3, $release_time, $timestamps, $path_16k_mp3
        if(strlen($fn_mp3) < 13){
            rename($dir . $fn_mp3, $dir . $timestamps . '.mp3');
            rename($dir . $fn_16k_mp3, $dir . $timestamps . '_16K.mp3');
            $html_string = str_replace($fn_mp3, $timestamps . '.mp3', $html_string);
            $html_string = str_replace($fn_16k_mp3, $timestamps . '_16K.mp3', $html_string);
            file_put_contents($fn, $html_string);
        } 
        // $html_string = str_replace($path_16k_mp3, 'audio04/', $html_string);
        // $html_string = str_replace($path_mp3, 'audio04/', $html_string);
    }
}

echo 'done';


// 返回当前的毫秒时间戳
function get_msectime(){
    list($msec, $sec) = explode('', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    return $msectime;
}
/**
 * 时间戳转日期格式：精确到毫秒，x代表毫秒
 * echo get_microtime_format($a*0.001);
 */
function get_microtime_format($time){
    if(strstr($time, '.')){
        sprintf("%01.3f", $time); // 小数点。不足三位补0
        list($usec, $sec) = explode(".", $time);
        $sec = str_pad($sec, 3, "0", STR_PAD_RIGHT); // 不足3位。右边补0
    }else{
        $usec = $time;
        $sec = "000";
    }
    $date = date("Y-m-d H:i:s.x", $usec);
    return str_replace('x', $sec, $date);
}
/**
 * 时间日期转时间戳格式，精确到毫秒，
 */
function get_data_format($time){
    list($usec, $sec) = explode(".", $time);
    $date = strtotime($usec);
    $return_data = str_pad($date . $sec, 13, "0", STR_PAD_RIGHT);
    return $return_data;
}
?>