<?php
ignore_user_abort();
set_time_limit(0);

$index_fn = 'x-index.html';

$book_path =  'diyao/';
$self_fn = $_SERVER['SCRIPT_NAME'];
$webroot = dirname($self_fn) . '/';

if(!file_exists($book_path)) mkdir($book_path, 0755, true);
$html_host = 'https://www.soundofhope.org';
$media_host = 'https://media.soundofhope.org';

$s = file_get_contents($book_path . $index_fn);
$s = str_replace($html_host, $self_fn . '?url=', $s);
file_put_contents($book_path . $index_fn, $s);

if(empty($_GET['url'])){
    header('Location: ' . $book_path . $index_fn);
    exit;
}
$url = 'https://www.soundofhope.org/post/368704';
$url = $_GET['url'];
$url = parse_url($url)['path'];
$ext = @pathinfo($url)['extension'];
$fn = basename($url);
if(empty($ext)) $fn = $fn . '.html';

# 含mp3的文件名不存在则下载, 如果变更条件中的 mp3 ，则不下载亦不输出
if(strpos($fn, '.mp3') !== false){
    if(!file_exists($book_path . 'audio04/' . $fn)){
        $url = $media_host . $url;
        $html = get_html($url, $charset='gbk');
        file_put_contents($book_path . 'audio04/' . $fn, $html);
        play_audio($book_path . 'audio04/' . $fn);
        exit;
    }else{
        play_audio($book_path . 'audio04/' . $fn);
        exit;
    }
}

# 如果文件已经存在，则不重复下载
if(file_exists($book_path . $fn)){
    if(strpos($fn, '.mp3') !== false) play_audio($book_path . $fn);
    else echo file_get_contents($book_path . $fn);
    exit;
}

# 判断文件名是否在指定的页面中，存在则完整URL备下载，不存在则终止
$index = file_get_contents($book_path . $index_fn);
if(strpos($index, $url) !== false) $url = $html_host . $url;
else die("<center><b>bad gateway <hr>502</b></center>");

// =====================================//

$html = get_html($url, $charset='gbk');

# 标题及音频链接
$start = '<h1 class="title">';
$end = '<div class="wave">';
$sub = div_node($html, $start, $end, $start_num=1, $end_num=0);
$sub = strip_tags($sub, '<h1><a>');
$sub = str_replace('href="', 'href="'. $self_fn .'?url=', $sub);
$sub = str_replace('download=""', 'target="_blank"', $sub); # 重要，不替换则下载

$sub_array = explode('</h1>', $sub);
$title = strip_tags($sub_array[0]);

# 作者，时间及标签
$start = '</h1>';
$end = '</div>';
$info = div_node($html, $start, $end, $start_num=2, $end_num=3);
$info = str_replace('</div><div', ' | </div><div', $info);
$info = str_replace('</a>', '、</a>', $info);
$info = strip_tags($info);
$info = "<p><small> " . $info . "</small><hr color=\"green\" align=left width=100%></p>";

# 文章内容
$start = '<p class="meta-top">';
// $start = '<h1 class="title">'; // 2 
$end = '<p class="meta-btm">';
$content = div_node($html, $start, $end, $start_num=1, $end_num=0);
$content = strip_tags($content, '<p><span>');
$content = str_replace('<span', '<span style="font-weight:bold"', $content);
$content .= "<b>责任编辑：紫君</b></p>\r\n";

# chapter 章节导航
$index_array = explode("\r\n", $index);
foreach($index_array as $key => $value){
    if(strpos($value, '</a>') !== false) break;
}
$value = strip_tags($value);
$chapter_max = (int) substr($value, 0, 3);

## 用章节链接做检索
$list_fn = $index_fn;
$current_fn = basename($url);
// echo $current_fn . "\r\n";
foreach($index_array as $key => $value){
    if(strpos($value, $current_fn) !== false){
        // echo $key .'=>'. $value . "\r\n";
        if(($key-1) > 0) $next_fn = trim(@$index_array[$key-1]);
        if(($key-1) === 0) $next_fn = '';
        if(($key+1) < $chapter_max+3) $previous_fn = trim(@$index_array[$key+1]);
        if(($key+1) === $chapter_max+3) $previous_fn = '';
    }
}

$chapter = "上一章--> ". $previous_fn ."   <a href=". $webroot . $book_path. $list_fn ."> <b>目录</b> </a>   下一章--> ". $next_fn;
$chapter = str_replace('（', '(', $chapter);
$chapter = str_replace('）', ')', $chapter);
$chapter = str_replace('<br>', '', $chapter);
$chapter = str_replace('(音频/视频)', '', $chapter);
$chapter = "<p><hr color=\"green\" align=left width=100%></p><pre>" . $chapter . "</pre>";

$article = $sub . $info . $content . $chapter;

$head = '<!DOCTYPE html><html lang="zh_CN"><head><meta charSet="utf-8"/><title>'. $title .'</title></head><body>';

$start = '<div class="copyright">';
$end = '</div>';
$footer = div_node($html, $start, $end, $start_num=1, $end_num=0);
$footer = "<br><br><small>$footer</small></body></html>";

$html = $head . $article . $footer . "\r\n";
$html = str_replace('><', ">\r\n<", $html);

echo $html;

file_put_contents($book_path . $fn, $html);

 













function play_audio($fn){
    $audio =  '<br><br><center><audio controls="controls">' . "\r\n";
    $audio .= '<source src="' . $fn . '" type="audio/mpeg">' . "\r\n";
    $audio .= 'Your browser does not support the audio tag.' . "\r\n";
    $audio .= '</audio></center>';
    echo $audio;
}

function get_html($url, $charset='gbk'){
    $path_parts = pathinfo($url);
    $refer = $path_parts['dirname'] . '/' . $_SERVER['PHP_SELF'];
    $option = array(
                    'http' => array('header' => "Referer:$refer"),
                    'ssl' => array('verify_peer' => false, 'verify_peer_name' => false,),
                    );
    $html = file_get_contents($url, false, stream_context_create($option));
    # 删除js
    // $preg = "/<script[\s\S]*?<\/script>/i";
    // $html = preg_replace($preg, "", $html, -1);
    // $html = str_replace("https://www.xbiquge.cc", "", $html);
    // if($charset == 'gbk') $html = mb_convert_encoding($html, "utf-8", "gbk");
    return $html;
}

function div_node($html, $start, $end, $start_num, $end_num){
    $array_start = explode($start, $html);
    $array_end = explode($end, $array_start[$start_num]);
    $node = '';
    foreach($array_end as $key => $value ){
        $node .= $value . $end;
        if($key == $end_num) break;
    }
    return $start . $node;
}   
