<?php

$url = 'https://www.soundofhope.org/post/364621';
$html = get_html($url, $charset='gbk');
$node1 = '<div class="ITDItem__Wrapper-e9dkg5-0 iavWFD item">';
$node2 = '<div class="post-btm">';
$array = explode($node1, $html);
$n = count($array);
$html = '';
foreach($array as $key => $node_more){
    if($key === 0) continue;
    if($key > 0 and $key < $n-1) $html .= $node1 . $node_more;
    if($key === $n-1){
        $node_end_array = explode('</a>', $node_more);
        $html .= $node1 . $node_end_array[0] . '</a></div>';
        break;
    }
}
$html = strip_tags($html, "<a>");
$html = str_replace('<a class="img-left"', '<a', $html);
$html = str_replace('</a>', "</a><br>\r\n", $html);
$html = str_replace('【帝尧的故事】', "", $html);
$html = "<meta charSet=\"utf-8\"/><h3>【帝尧的故事】</h3>\r\n" . $html;
$html = str_replace('<a href="', '<a href="https://www.soundofhope.org', $html);

// echo getcwd();
foreach(glob('*.html') as $file ){
 unlink($file);
}


file_put_contents(date("Ymd").'-list.html', $html);
 
file_put_contents('diyao/x-index.html', $html);
  
// echo $html;
echo file_get_contents('diyao/x-index.html');

// https://img.soundofhope.org/styles/dfl/public/upload/image04/2019-12/1576900541477.jpg



function get_html($url, $charset='gbk'){
    $path_parts = pathinfo($url);
    $refer = $path_parts['dirname'] . '/' . $_SERVER['PHP_SELF'];
    $refer = 'https://www.soundofhope.org/term/364';
    $option = array(
                    'http' => array('header' => "Referer:$refer"),
                    'ssl' => array('verify_peer' => false, 'verify_peer_name' => false,),
                    );
    $html = file_get_contents($url, false, stream_context_create($option));
    # 删除js
    $preg = "/<script[\s\S]*?<\/script>/i";
    $html = preg_replace($preg, "", $html, -1);
    //if($charset == 'gbk') $html = mb_convert_encoding($html, "utf-8", "gbk");
    return $html;
}








