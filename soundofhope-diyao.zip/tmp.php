<?php
# ASCII (194,160) 为异常空格
ignore_user_abort();
set_time_limit(0);
echo '<pre>';
foreach (glob('diyao/*.html') as $fn) {
    $html = file_get_contents($fn);

    $link_array = getlink($html);
    
    # 替换 URL
    foreach($link_array as $url){
        $url_fn = basename($url);
        echo $url_fn . "<br>\r\n";
        if(strpos($url_fn, '.mp3') !== false){
            if(strpos($url_fn, '_16K.mp3') !== false){
                $newurl = 'audio04/16K-mp3/'.$url_fn;
                $html = str_replace($url, $newurl, $html);
            }else{
                $newurl = 'audio04/'.$url_fn;
                $html = str_replace($url, $newurl, $html);
            }
        }
        if(strpos($url_fn, '.') == false){
            $newurl = $url_fn . '.html';
            $html = str_replace($url, $newurl, $html);
        }
        if(strpos($url_fn, 'x-index.html') !== false){
            $newurl = 'index.html';
            $html = str_replace($url, $newurl, $html);
        }
    }
    
    # 替换 copyright
    $cr = '<div class="copyright">';
    $newcr = '<div style="font-size:8px; text-align:center " class="copyright">';
    $html = str_replace($cr, $newcr, $html);
    
    file_put_contents($fn, $html);
}



function getlink($html){
    $array_url = array();
    $dom = new DOMDocument();
    @$dom -> loadHTML($html);
    $xpath = new DOMXPath($dom);
    $hrefs = $xpath -> evaluate("/html/body//a");
    for($i = 0;$i < $hrefs -> length;$i++){
        $href = $hrefs -> item($i);
        $url = $href -> getAttribute('href');
        $array_url[] .= $url;
        // echo $url . "<br/>\r\n";
    }
    return array_unique($array_url);
}

