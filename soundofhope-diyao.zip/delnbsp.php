<?php
# ASCII (194,160) 为异常空格
ignore_user_abort();
set_time_limit(0);
echo '<pre>';
foreach (glob('diyao/*.html') as $fn) {
    $html = file_get_contents($fn);
    for ($i = 0; $i < 30; $i++) {
        $html = str_replace('&nbsp;', '', $html);
        $html = str_replace("\t", '', $html);
        $html = str_replace(' ', ' ', $html); // $html = str_replace(chr(194), '', $html);
        $html = str_replace('  ', ' ', $html);
        $html = str_replace('　', ' ', $html);
        $html = str_replace('> ', '>', $html);
        $html = str_replace(' <', '<', $html);
    }
    $html = str_replace('80%', '100%', $html);
    $html = str_replace('</a>', '</a>    ', $html);
    $html = str_replace('-->', ' --> ', $html);
    file_put_contents($fn, $html);
    echo $fn . " --- done\r\n";
}
